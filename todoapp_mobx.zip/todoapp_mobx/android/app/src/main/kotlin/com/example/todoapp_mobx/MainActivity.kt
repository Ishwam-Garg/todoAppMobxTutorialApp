package com.example.todoapp_mobx

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
